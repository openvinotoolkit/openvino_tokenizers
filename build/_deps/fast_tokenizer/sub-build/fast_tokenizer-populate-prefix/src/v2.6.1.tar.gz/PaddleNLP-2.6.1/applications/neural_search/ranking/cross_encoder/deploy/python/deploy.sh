python deploy/python/predict.py --model_dir ./output \
                                --input_file data/test.csv \
                                --model_name_or_path rocketqa-base-cross-encoder